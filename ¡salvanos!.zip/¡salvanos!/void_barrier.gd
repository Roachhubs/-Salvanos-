extends Node2D

# Define the spawn point coordinates where the sprite should return
@export var spawn_position: Vector2 = Vector2(100, 100)

func _on_void_barrier_body_entered(body: Node) -> void:
	# Check if the body that entered the void is your player sprite
	if body.is_in_group("player") or body.name == "Player":
		
		# If using a CharacterBody2D/RigidBody2D, you must clear velocities
		if body.has_method("set_velocity"):
			body.velocity = Vector2.ZERO
			
		# Teleport the sprite back
		body.global_position = spawn_position
